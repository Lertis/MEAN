import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-wrapper',
  templateUrl: './employee-wrapper.component.html',
  styleUrls: ['./employee-wrapper.component.scss']
})
export class EmployeeWrapperComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
