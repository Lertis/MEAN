export interface IEmployee {
    _id: string;
    name: string;
    position: string;
    office: string;
    salary: number;
}